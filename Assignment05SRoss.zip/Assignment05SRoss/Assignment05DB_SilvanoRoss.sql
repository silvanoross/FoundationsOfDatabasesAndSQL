--*************************************************************************--
-- Title: Assignment05
-- Author: SilvanoRoss
-- Desc: This file demonstrates how to use Joins and Subqueiers
-- Change Log: When,Who,What
-- 2021-11-13,SilvanoRoss,Created File, Completed problems 1-5
-- 2021-11-14,SilvanoRoss, Completed problems 6 & 7
--
--**************************************************************************--
Use Master;
go

If Exists(Select Name From SysDatabases Where Name = 'Assignment05DB_SilvanoRoss')
 Begin 
  Alter Database [Assignment05DB_SilvanoRoss] set Single_user With Rollback Immediate;
  Drop Database Assignment05DB_SilvanoRoss;
 End
go

Create Database Assignment05DB_SilvanoRoss;
go

Use Assignment05DB_SilvanoRoss;
go

-- Create Tables (Module 01)-- 
Create Table Categories
([CategoryID] [int] IDENTITY(1,1) NOT NULL 
,[CategoryName] [nvarchar](100) NOT NULL
);
go

Create Table Products
([ProductID] [int] IDENTITY(1,1) NOT NULL 
,[ProductName] [nvarchar](100) NOT NULL 
,[CategoryID] [int] NULL  
,[UnitPrice] [mOney] NOT NULL
);
go

Create Table Employees -- New Table
([EmployeeID] [int] IDENTITY(1,1) NOT NULL 
,[EmployeeFirstName] [nvarchar](100) NOT NULL
,[EmployeeLastName] [nvarchar](100) NOT NULL 
,[ManagerID] [int] NULL  
);
go

Create Table Inventories
([InventoryID] [int] IDENTITY(1,1) NOT NULL
,[InventoryDate] [Date] NOT NULL
,[EmployeeID] [int] NOT NULL -- New Column
,[ProductID] [int] NOT NULL
,[Count] [int] NOT NULL
);
go

-- Add Constraints (Module 02) -- 
Begin  -- Categories
	Alter Table Categories 
	 Add Constraint pkCategories 
	  Primary Key (CategoryId);

	Alter Table Categories 
	 Add Constraint ukCategories 
	  Unique (CategoryName);
End
go 

Begin -- Products
	Alter Table Products 
	 Add Constraint pkProducts 
	  Primary Key (ProductId);

	Alter Table Products 
	 Add Constraint ukProducts 
	  Unique (ProductName);

	Alter Table Products 
	 Add Constraint fkProductsToCategories 
	  Foreign Key (CategoryId) References Categories(CategoryId);

	Alter Table Products 
	 Add Constraint ckProductUnitPriceZeroOrHigher 
	  Check (UnitPrice >= 0);
End
go

Begin -- Employees
	Alter Table Employees
	 Add Constraint pkEmployees 
	  Primary Key (EmployeeId);

	Alter Table Employees 
	 Add Constraint fkEmployeesToEmployeesManager 
	  Foreign Key (ManagerId) References Employees(EmployeeId);
End
go

Begin -- Inventories
	Alter Table Inventories 
	 Add Constraint pkInventories 
	  Primary Key (InventoryId);

	Alter Table Inventories
	 Add Constraint dfInventoryDate
	  Default GetDate() For InventoryDate;

	Alter Table Inventories
	 Add Constraint fkInventoriesToProducts
	  Foreign Key (ProductId) References Products(ProductId);

	Alter Table Inventories 
	 Add Constraint ckInventoryCountZeroOrHigher 
	  Check ([Count] >= 0);

	Alter Table Inventories
	 Add Constraint fkInventoriesToEmployees
	  Foreign Key (EmployeeId) References Employees(EmployeeId);
End 
go

-- Adding Data (Module 04) -- 
Insert Into Categories 
(CategoryName)
Select CategoryName 
 From Northwind.dbo.Categories
 Order By CategoryID;
go

Insert Into Products
(ProductName, CategoryID, UnitPrice)
Select ProductName,CategoryID, UnitPrice 
 From Northwind.dbo.Products
  Order By ProductID;
go

Insert Into Employees
(EmployeeFirstName, EmployeeLastName, ManagerID)
Select E.FirstName, E.LastName, IsNull(E.ReportsTo, E.EmployeeID) 
 From Northwind.dbo.Employees as E
  Order By E.EmployeeID;
go


Insert Into Inventories
(InventoryDate, EmployeeID, ProductID, [Count])
Select '20170101' as InventoryDate, 5 as EmployeeID, ProductID, UnitsInStock
From Northwind.dbo.Products
UNIOn
Select '20170201' as InventoryDate, 7 as EmployeeID, ProductID, UnitsInStock + 10 -- Using this is to create a made up value
From Northwind.dbo.Products
UNIOn
Select '20170301' as InventoryDate, 9 as EmployeeID, ProductID, UnitsInStock + 20 -- Using this is to create a made up value
From Northwind.dbo.Products
Order By 1, 2
go


-- Show the Current data in the Categories, Products, and Inventories Tables
Select * From Categories;
go
Select * From Products;
go
Select * From Employees;
go
Select * From Inventories;
go

/********************************* Questions and Answers *********************************/
-- Question 1 (10 pts): How can you show a list of Category and Product names, 
-- and the price of each product?
-- Order the result by the Category and Product!

--Select all data
--SELECT * FROM Categories; 
--SELECT * FROM Products;

--Select specific columns and join tables
--SELECT CategoryName, ProductName, UnitPrice AS [Price of Product]
--	FROM Categories INNER JOIN Products
--	ON Categories.CategoryID = Products.CategoryID;
--GO

--Order data
--SELECT CategoryName, ProductName, UnitPrice AS [Price of Product]
--	FROM Categories INNER JOIN Products
--	ON Categories.CategoryID = Products.CategoryID
-- ORDER BY 1,2;
--GO

--Format Code
SELECT CategoryName, ProductName, UnitPrice AS [Price of Product]
	FROM Categories INNER JOIN Products
	ON Categories.CategoryID = Products.CategoryID
 ORDER BY 1,2;
GO


-- Question 2 (10 pts): How can you show a list of Product name 
-- and Inventory Counts on each Inventory Date?
-- Order the results by the Date, Product,  and Count!

--Select all data
--SELECT * FROM Products;
--SELECT * FROM Inventories;
--GO

--Select column names, aliases and join tables
--SELECT ProductName, [Count], InventoryDate AS [Date]
--	FROM Products INNER JOIN Inventories
--	ON Products.ProductID = Inventories.ProductID;
--GO

--Order data
--SELECT ProductName, [Count], InventoryDate AS [Date]
--	FROM Products as P INNER JOIN Inventories as I
--	ON P.ProductID = I.ProductID
-- ORDER BY 3,1,2;
--GO

SELECT ProductName, InventoryDate AS [Date], [Count]
	FROM Products as P INNER JOIN Inventories as I
	ON P.ProductID = I.ProductID
 ORDER BY 2,1,3;
GO

-- Question 3 (10 pts): How can you show a list of Inventory Dates 
-- and the Employee that took the count?
-- Order the results by the Date and return only one row per date!

--Select all data
--SELECT * FROM Inventories;
--SELECT * FROM Employees;
--GO

--Select columns, aliases and join tables
--SELECT InventoryDate AS [Date of Inventory], 
--	   EmployeeFirstName as [First Name],
--	   EmployeeLastName AS [Last Name]
--	   FROM Inventories AS I INNER JOIN Employees AS E
--	   ON I.EmployeeID = E.EmployeeID;
--GO

--Combine columns to form single "employee name" column
--SELECT DISTINCT InventoryDate AS [Date of Inventory], 
--	   (EmployeeFirstName + ' ' + EmployeeLastName) AS [Employee Name]
--	   FROM Inventories AS I INNER JOIN Employees AS E
--	   ON I.EmployeeID = E.EmployeeID
--	ORDER BY InventoryDate;
--GO

--Order data
--SELECT DISTINCT InventoryDate AS [Date of Inventory], 
--	   EmployeeFirstName as [First Name],
--	   EmployeeLastName AS [Last Name]
--	   FROM Inventories AS I INNER JOIN Employees AS E
--	   ON I.EmployeeID = E.EmployeeID
--	ORDER BY InventoryDate;
--GO

--Format
SELECT DISTINCT InventoryDate AS [Date of Inventory], 
	   (EmployeeFirstName + ' ' + EmployeeLastName) AS [Employee Name]
	   FROM Inventories AS I
	    INNER JOIN Employees AS E
	   ON I.EmployeeID = E.EmployeeID
	ORDER BY InventoryDate;
GO
-- Question 4 (10 pts): How can you show a list of Categories, Products, 
-- and the Inventory Date and Count of each product?
-- Order the results by the Category, Product, Date, and Count!

--Select all data
--SELECT * FROM Categories;
--SELECT * FROM Products;
--SELECT * FROM Inventories;
--GO

--Select column names and join multiple tables
--SELECT 
--	CategoryName,
--	ProductName,
--	InventoryDate,
--	[Count]
--FROM Categories AS Cat
--	 INNER JOIN Products AS Pro
--	ON Cat.CategoryID = Pro.CategoryID
--	 INNER JOIN Inventories as Inv
--	ON Inv.ProductID = Pro.ProductID;
--GO

--Order by
--SELECT 
--	CategoryName,
--	ProductName,
--	InventoryDate,
--	[Count]
--FROM Categories AS Cat
--	 INNER JOIN Products AS Pro
--	ON Cat.CategoryID = Pro.CategoryID
--	 INNER JOIN Inventories as Inv
--	ON Inv.ProductID = Pro.ProductID
-- ORDER BY 1,2,3,4;
--GO

--Format Code
SELECT 
	CategoryName,
	ProductName,
	InventoryDate,
	[Count]
FROM Categories AS Cat
	 INNER JOIN Products AS Pro
	ON Cat.CategoryID = Pro.CategoryID
	 INNER JOIN Inventories as Inv
	ON Inv.ProductID = Pro.ProductID
 ORDER BY 1,2,3,4;
GO


-- Question 5 (20 pts): How can you show a list of Categories, Products, 
-- the Inventory Date and Count of each product, and the EMPLOYEE who took the count?
-- Order the results by the Inventory Date, Category, Product and Employee!

--Select All data
--SELECT * FROM Categories;
--SELECT * FROM Products;
--SELECT * FROM Inventories;
--SELECT * FROM Employees;
--GO

--Select column names and join multiple tables
--SELECT 
--	CategoryName,
--	ProductName,
--	InventoryDate,
--	[Count],
--	[First Name] = EmployeeFirstName,
--	[Last Name] = EmployeeLastName
--FROM Categories AS Cat
--	 INNER JOIN Products AS Pro
--	ON Cat.CategoryID = Pro.CategoryID
--	 INNER JOIN Inventories as Inv
--	ON Inv.ProductID = Pro.ProductID
--	 INNER JOIN Employees AS Emp
--	ON Emp.EmployeeID = Inv.EmployeeID;
--GO

--Order data
--SELECT 
--	CategoryName,
--	ProductName,
--	InventoryDate,
--	[Count],
--	[First Name] = EmployeeFirstName,
--	[Last Name] = EmployeeLastName
--FROM Categories AS Cat
--	 INNER JOIN Products AS Pro
--	ON Cat.CategoryID = Pro.CategoryID
--	 INNER JOIN Inventories as Inv
--	ON Inv.ProductID = Pro.ProductID
--	 INNER JOIN Employees AS Emp
--	ON Emp.EmployeeID = Inv.EmployeeID
-- ORDER BY 3,1,2, 5,6
--GO

--Convert employee name to one column
--SELECT 
--	CategoryName,
--	ProductName,
--	InventoryDate,
--	[Count],
--	[Employee Name] = (EmployeeFirstName + ' ' + EmployeeLastName)
--FROM Categories AS Cat
--	 INNER JOIN Products AS Pro
--	ON Cat.CategoryID = Pro.CategoryID
--	 INNER JOIN Inventories as Inv
--	ON Inv.ProductID = Pro.ProductID
--	 INNER JOIN Employees AS Emp
--	ON Emp.EmployeeID = Inv.EmployeeID
-- ORDER BY 3,1,2, 5
--GO

--Format data
SELECT 
	CategoryName,
	ProductName,
	InventoryDate,
	[Count],
	[Employee Name] = (EmployeeFirstName + ' ' +
	EmployeeLastName)
FROM Categories AS Cat
	 INNER JOIN Products AS Pro
	ON Cat.CategoryID = Pro.CategoryID
	 INNER JOIN Inventories as Inv
	ON Inv.ProductID = Pro.ProductID
	 INNER JOIN Employees AS Emp
	ON Emp.EmployeeID = Inv.EmployeeID
 ORDER BY 3,1,2,5
GO

-- Question 6 (20 pts): How can you show a list of Categories, Products, 
-- the Inventory Date and Count of each product, and the Employee who took the count
-- for the Products 'Chai' and 'Chang'? 
-- For Practice; Use a Subquery to get the ProductID based on the Product Names 
-- and order the results by the Inventory Date, Category, and Product!

--Select all data
--SELECT * FROM Categories;
--SELECT * FROM Products;
--SELECT * FROM Inventories;
--SELECT * FROM Employees; 
--GO

--Select column names and join tables
--SELECT CategoryName,
--	   ProductID,
--	   ProductName,
--	   InventoryDate,
--	   [Count],
--	   [First Name] = EmployeeFirstName,
--	   [Last Name] = EmployeeLastName
--FROM Categories AS Cat
--	 INNER JOIN Products AS Pro
--	ON Cat.CategoryID = Pro.CategoryID
--	 INNER JOIN Inventories as Inv
--	ON Inv.ProductID = Pro.ProductID
--	 INNER JOIN Employees AS Emp
--	ON Emp.EmployeeID = Inv.EmployeeID;
--GO

--create subquieries for restriction to Product Name of 'Chai' and 'Chang'
--SELECT CategoryName,
--	   ProductName, 
--	   InventoryDate,
--	   [Count],
--	   [First Name] = EmployeeFirstName,
--	   [Last Name] = EmployeeLastName
--FROM Categories AS Cat
--	 INNER JOIN Products AS Pro
--	ON Cat.CategoryID = Pro.CategoryID
--	 INNER JOIN Inventories as Inv
--	ON Inv.ProductID = Pro.ProductID
--	 INNER JOIN Employees AS Emp
--	ON Emp.EmployeeID = Inv.EmployeeID
-- WHERE Pro.ProductID IN ((SELECT ProductID FROM Products WHERE ProductName = 'Chai'), 
--                         (SELECT ProductID FROM Products WHERE ProductName = 'Chang'));
--GO

--Convert Employee name to one column
--SELECT CategoryName,
--	   ProductName, 
--	   InventoryDate,
--	   [Count],
--	   [Employee Name] = (EmployeeFirstName + ' ' + EmployeeLastName)
--FROM Categories AS Cat
--	 INNER JOIN Products AS Pro
--	ON Cat.CategoryID = Pro.CategoryID
--	 INNER JOIN Inventories as Inv
--	ON Inv.ProductID = Pro.ProductID
--	 INNER JOIN Employees AS Emp
--	ON Emp.EmployeeID = Inv.EmployeeID
-- WHERE Pro.ProductID IN ((SELECT ProductID FROM Products WHERE ProductName = 'Chai'), 
--                         (SELECT ProductID FROM Products WHERE ProductName = 'Chang'));
--GO

--Format code
SELECT CategoryName, --1
	   ProductName, --2
	   InventoryDate, --3
	   [Count], --4
	   [Employee Name] = (EmployeeFirstName + ' ' + 
	   EmployeeLastName) --5
FROM Categories AS Cat
	 INNER JOIN Products AS Pro
	ON Cat.CategoryID = Pro.CategoryID
	 INNER JOIN Inventories as Inv
	ON Inv.ProductID = Pro.ProductID
	 INNER JOIN Employees AS Emp
	ON Emp.EmployeeID = Inv.EmployeeID
 WHERE Pro.ProductID IN (
		(SELECT ProductID 
			FROM Products 
				WHERE ProductName = 'Chai'), 
        (SELECT ProductID 
			FROM Products 
				WHERE ProductName = 'Chang'))
 ORDER BY 3,1,2;
GO

-- Question 7 (20 pts): How can you show a list of Employees and the Manager who manages them?
-- Order the results by the Manager's name!

--Select all data
--SELECT * FROM Employees;


SELECT  M. EmployeeFirstName + ' ' + 
			M.EmployeeLastName AS 'Manager',

		E.EmployeeFirstName + ' ' + 
			E.EmployeeLastName AS 'Employee'
       
	FROM Employees AS M
	 INNER JOIN Employees AS E
	ON M.EmployeeID = E.ManagerID
ORDER BY 1,2;

GO



/***************************************************************************************/